
<html >
<head>
  <meta charset="UTF-8">
  <title>Access Denied</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="css/style.css">

      <script language="JavaScript" src="js/admin.js">
	</script>

  
</head>
<body style="background-image:url('images/demo/backgrounds/access2.jpg');">

<div class="pen-title">
  <h1 style="color:white;"> Online Voting System Access Denied </h1>
 
</div>

<div class="container" >
  <div class="card"></div>

  <div class="card">
    <h1 class="title">Access Denied!</h1>
    <form name="form1" method="post" action="checklogin.php" onsubmit="return loginValidate(this)">

   
      <div id="container">
<center><b><p style="color:#000000";>  You don't have access to this resource. <a href="index.php">
  			<br><br>
  			<em>Click here</em></a> to login first.</p></b>
  			</center> 
	</div>
      

    </form>
  </div>
  
</div>


</body>
</html>